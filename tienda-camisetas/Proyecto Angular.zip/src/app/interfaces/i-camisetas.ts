export interface Camiseta {
  id: number;
  nombre_equipo: string;
  temporada: string;
  marca: string;
  talla: string;
  precio: number;
  stock: number;
  imagen: string;
}