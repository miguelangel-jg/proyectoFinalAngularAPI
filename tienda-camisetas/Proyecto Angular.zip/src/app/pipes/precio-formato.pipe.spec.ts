import { PrecioFormatoPipe } from './precio-formato.pipe';

describe('PrecioFormatoPipe', () => {
  it('create an instance', () => {
    const pipe = new PrecioFormatoPipe();
    expect(pipe).toBeTruthy();
  });
});
